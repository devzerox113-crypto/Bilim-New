import { adminClient } from "./supabase";

export type Plan = { code: string; message_limit: number; allowed_models: string[] };

/** Тариф определяется ТОЛЬКО по серверным данным подписки. */
export async function getActivePlan(userId: string): Promise<Plan> {
  const db = adminClient();
  const { data: sub } = await db.from("subscriptions")
    .select("status, expires_at, subscription_plans(code, message_limit, allowed_models)")
    .eq("user_id", userId).eq("status", "active")
    .gt("expires_at", new Date().toISOString())
    .order("expires_at", { ascending: false }).limit(1).maybeSingle();
  const p = (sub as any)?.subscription_plans;
  if (p) return p;
  const { data: free } = await db.from("subscription_plans")
    .select("code, message_limit, allowed_models").eq("code", "FREE").single();
  return free as Plan;
}

export async function messagesToday(userId: string): Promise<number> {
  const start = new Date(); start.setUTCHours(0, 0, 0, 0);
  const { count } = await adminClient().from("messages")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId).eq("role", "user").gte("created_at", start.toISOString());
  return count ?? 0;
}

export function modelFor(plan: Plan): string | null {
  return process.env[`OPENAI_MODEL_${plan.code}`] || null;
}
