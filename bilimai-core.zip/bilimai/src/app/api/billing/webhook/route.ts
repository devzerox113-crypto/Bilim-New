import crypto from "node:crypto";
import { adminClient } from "@/lib/supabase";

/**
 * ШАБЛОН: имя заголовка подписи и поля payload привести к документации провайдера.
 * Проверка HMAC по сырому телу, идемпотентность и активация только после
 * подтверждённого события — рабочая логика.
 */
export async function POST(req: Request) {
  const raw = await req.text();
  const secret = process.env.BILLING_WEBHOOK_SECRET;
  if (!secret) return new Response("not configured", { status: 503 });

  const sig = req.headers.get("x-signature") ?? "";
  const expected = crypto.createHmac("sha256", secret).update(raw).digest("hex");
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return new Response("bad signature", { status: 401 });

  const ev = JSON.parse(raw) as {
    type: string; payment_id: string; user_id: string; plan_code: string;
    amount: number; currency: string; subscription_id?: string;
  };
  const db = adminClient();

  if (ev.type === "payment.succeeded") {
    const { data: plan } = await db.from("subscription_plans").select("id, duration_days").eq("code", ev.plan_code).single();
    if (!plan) return new Response("unknown plan", { status: 400 });

    const { error } = await db.from("payments").insert({
      user_id: ev.user_id, provider: "provider", provider_payment_id: ev.payment_id,
      amount: ev.amount, currency: ev.currency, status: "succeeded" });
    if (error?.code === "23505") return new Response("duplicate", { status: 200 });
    if (error) return new Response("db error", { status: 500 });

    const now = new Date();
    await db.from("subscriptions").insert({
      user_id: ev.user_id, plan_id: plan.id, status: "active", provider: "provider",
      provider_subscription_id: ev.subscription_id, started_at: now.toISOString(),
      expires_at: new Date(now.getTime() + plan.duration_days * 864e5).toISOString(),
      last_confirmed_at: now.toISOString() });
  }
  return new Response("ok");
}
