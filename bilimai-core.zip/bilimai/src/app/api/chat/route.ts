import OpenAI from "openai";
import { z } from "zod";
import { userClient, adminClient } from "@/lib/supabase";
import { getActivePlan, messagesToday, modelFor } from "@/lib/limits";

export const maxDuration = 60;
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const Body = z.object({ chatId: z.string().uuid(), content: z.string().min(1).max(8000) });
const err = (status: number, code: string, message: string) =>
  Response.json({ error: { code, message } }, { status });

export async function POST(req: Request) {
  const sb = await userClient();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return err(401, "unauthorized", "Войдите в аккаунт.");

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return err(400, "bad_request", "Неверный запрос.");
  const { chatId, content } = parsed.data;

  const { data: chat } = await sb.from("chats").select("id").eq("id", chatId).maybeSingle();
  if (!chat) return err(404, "not_found", "Чат не найден.");

  const plan = await getActivePlan(user.id);
  if ((await messagesToday(user.id)) >= plan.message_limit)
    return err(429, "limit_reached", "Дневной лимит сообщений исчерпан. Обновите тариф или вернитесь завтра.");
  const model = modelFor(plan);
  if (!model) return err(503, "model_unavailable", "Модель для вашего тарифа не настроена.");

  const db = adminClient();
  await db.from("messages").insert({ chat_id: chatId, user_id: user.id, role: "user", content });
  const { data: history } = await db.from("messages").select("role, content")
    .eq("chat_id", chatId).neq("status", "error").order("created_at", { ascending: false }).limit(30);
  const msgs = (history ?? []).reverse() as { role: "user" | "assistant"; content: string }[];

  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let full = "", inTok = 0, outTok = 0;
      try {
        const res = await openai.chat.completions.create(
          { model, messages: msgs, stream: true, stream_options: { include_usage: true } },
          { signal: req.signal, timeout: 55_000 }
        );
        for await (const chunk of res) {
          const delta = chunk.choices[0]?.delta?.content ?? "";
          if (delta) { full += delta; controller.enqueue(enc.encode(delta)); }
          if (chunk.usage) { inTok = chunk.usage.prompt_tokens; outTok = chunk.usage.completion_tokens; }
        }
      } catch (e: any) {
        console.error("openai_error", e?.status, e?.code);
        if (!req.signal.aborted) controller.enqueue(enc.encode(
          e?.status === 429 ? "\n\n[Сервис перегружен или закончился бюджет API. Попробуйте позже.]"
          : "\n\n[Ошибка генерации. Попробуйте ещё раз.]"));
      } finally {
        if (full) {
          await db.from("messages").insert({ chat_id: chatId, user_id: user.id, role: "assistant",
            content: full, model, input_tokens: inTok, output_tokens: outTok });
          await db.from("usage_records").insert({ user_id: user.id, chat_id: chatId, model,
            input_tokens: inTok, output_tokens: outTok });
          await db.from("chats").update({ updated_at: new Date().toISOString() }).eq("id", chatId);
        }
        controller.close();
      }
    },
  });
  return new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
}
