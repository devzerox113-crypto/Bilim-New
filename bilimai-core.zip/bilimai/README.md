# BilimAi — статус реализации

## Готово (код написан, НЕ запускался и не тестировался)
- supabase/migrations/0001_init.sql — 12 таблиц, индексы, RLS, триггер профиля
- POST /api/chat — сессия, валидация, доступ к чату, лимиты по тарифу, стрим OpenAI, сохранение, учёт токенов
- POST /api/billing/webhook — HMAC-подпись, идемпотентность, активация подписки (шаблон под провайдера)
- GET /api/health

## Не сделано
UI (главная, чат, кабинет, тарифы), auth-страницы, файлы/изображения, голос,
админка, остальные API, Android, GitHub Actions, тесты, checkout-маршрут.

## Запуск
1. `supabase db push` (или SQL из миграции в SQL Editor)
2. Скопировать `.env.example` в `.env.local`, заполнить; задать OPENAI_MODEL_FREE/PLUS/PRO актуальными моделями из вашего аккаунта OpenAI
3. `npm i && npm run dev`
4. В Vercel добавить те же переменные (Production и Preview)
5. Первого админа: `insert into admin_users(user_id) values ('<uuid>')` в SQL Editor
