create extension if not exists pgcrypto;

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text, avatar_url text,
  preferred_language text not null default 'ru' check (preferred_language in ('ru','kk','en')),
  theme text not null default 'system' check (theme in ('light','dark','system')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table admin_users (user_id uuid primary key references auth.users(id) on delete cascade, created_at timestamptz not null default now());

create table subscription_plans (
  id uuid primary key default gen_random_uuid(),
  code text unique not null check (code in ('FREE','PLUS','PRO')),
  name text not null, price numeric(12,2) not null default 0, currency text not null default 'KZT',
  duration_days int not null default 30, message_limit int not null, file_limit int not null,
  allowed_models text[] not null default '{}', features jsonb not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
insert into subscription_plans (code,name,price,message_limit,file_limit) values
 ('FREE','Free',0,20,3),('PLUS','Plus',1990,300,30),('PRO','Pro',4990,1000,100);

create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id uuid not null references subscription_plans(id),
  status text not null check (status in ('active','pending','canceled','expired','past_due')),
  started_at timestamptz, expires_at timestamptz, provider text, provider_subscription_id text,
  last_confirmed_at timestamptz, canceled_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on subscriptions(user_id, status);

create table payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subscription_id uuid references subscriptions(id),
  provider text not null, provider_payment_id text not null,
  amount numeric(12,2) not null, currency text not null,
  status text not null check (status in ('pending','succeeded','failed','refunded')),
  created_at timestamptz not null default now(),
  unique (provider, provider_payment_id)
);

create table chats (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Новый чат', is_archived boolean not null default false,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create index on chats(user_id, updated_at desc);

create table messages (
  id uuid primary key default gen_random_uuid(),
  chat_id uuid not null references chats(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant','system')),
  content text not null, model text, input_tokens int, output_tokens int,
  status text not null default 'done' check (status in ('pending','done','error')),
  created_at timestamptz not null default now()
);
create index on messages(chat_id, created_at);
create index on messages(user_id, role, created_at);

create table usage_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  chat_id uuid references chats(id) on delete set null,
  model text, input_tokens int, output_tokens int, estimated_cost numeric(12,6),
  created_at timestamptz not null default now()
);
create index on usage_records(user_id, created_at);

create table attachments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  chat_id uuid references chats(id) on delete cascade,
  storage_path text not null, filename text not null, mime_type text not null,
  file_size bigint not null check (file_size > 0), created_at timestamptz not null default now()
);
create table user_settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  language text not null default 'ru', theme text not null default 'system',
  voice_enabled boolean not null default false, response_preferences jsonb not null default '{}',
  updated_at timestamptz not null default now()
);
create table notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, body text, read_at timestamptz, created_at timestamptz not null default now()
);
create table feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  chat_id uuid references chats(id) on delete set null,
  rating int check (rating between 1 and 5), message text, created_at timestamptz not null default now()
);
create table admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_user_id uuid not null references auth.users(id),
  action text not null, target_type text, target_id text, metadata jsonb,
  created_at timestamptz not null default now()
);

create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, display_name) values (new.id, split_part(new.email,'@',1));
  insert into user_settings(user_id) values (new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table profiles enable row level security;
alter table admin_users enable row level security;
alter table subscription_plans enable row level security;
alter table subscriptions enable row level security;
alter table payments enable row level security;
alter table chats enable row level security;
alter table messages enable row level security;
alter table usage_records enable row level security;
alter table attachments enable row level security;
alter table user_settings enable row level security;
alter table notifications enable row level security;
alter table feedback enable row level security;
alter table admin_audit_logs enable row level security;

create policy plans_read on subscription_plans for select using (is_active);
create policy profiles_sel on profiles for select using (id = auth.uid());
create policy profiles_upd on profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy settings_all on user_settings for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy chats_sel on chats for select using (user_id = auth.uid());
create policy chats_ins on chats for insert with check (user_id = auth.uid());
create policy chats_upd on chats for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy chats_del on chats for delete using (user_id = auth.uid());
create policy msgs_sel on messages for select using (user_id = auth.uid());
create policy subs_sel on subscriptions for select using (user_id = auth.uid());
create policy pay_sel on payments for select using (user_id = auth.uid());
create policy usage_sel on usage_records for select using (user_id = auth.uid());
create policy att_sel on attachments for select using (user_id = auth.uid());
create policy att_del on attachments for delete using (user_id = auth.uid());
create policy notif_sel on notifications for select using (user_id = auth.uid());
create policy notif_upd on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy fb_ins on feedback for insert with check (user_id = auth.uid());
create policy fb_sel on feedback for select using (user_id = auth.uid());
